

package com.capgemini.repo;

import java.math.BigDecimal;

import com.capg.exce.InvalidPhoneNumberException;
import com.capg.exce.MobileNumberAlreadyExistException;
import com.capgemini.beans.Customer;


public interface WalletRepo {
	//public boolean save(Customer c) throws MobileNumberAlreadyExistException;
	public Customer findByOne(String mobileNo) throws InvalidPhoneNumberException;
	public boolean update(String mobileNo,BigDecimal balance);
	public boolean updateTransaction(int id,String mobileNo,String Type,BigDecimal balance);

}
