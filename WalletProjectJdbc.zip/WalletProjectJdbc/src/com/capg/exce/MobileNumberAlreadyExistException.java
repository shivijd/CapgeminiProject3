package com.capg.exce;

public class MobileNumberAlreadyExistException extends Exception {

}
