package com.capg.exce;

public class InvalidAmountPresentException extends Exception {

}
