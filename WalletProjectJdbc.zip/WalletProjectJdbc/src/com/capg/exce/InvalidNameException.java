package com.capg.exce;

public class InvalidNameException extends Exception {

}
