package com.capg.main;

import java.math.BigDecimal;
import com.capg.exce.InvalidAmountPresentException;
import com.capg.exce.InvalidPhoneNumberException;
import com.capgemini.Service.WalletService;
import com.capgemini.Service.WalletServiceImplementation;
import com.capgemini.repo.WalletRepo;
import com.capgemini.repo.WalletRepoImplementation;

public class MainClas {

	public static void main(String[] args) throws InvalidAmountPresentException, InvalidPhoneNumberException {
		WalletRepo wal=new WalletRepoImplementation();
		WalletService walS=new WalletServiceImplementation(wal);			
		walS.withdrawAmount(  "7500725707", new BigDecimal("500"));
		walS.depositAmount( "9198268281", new BigDecimal("1000"));
		// walS.fundTransfer( "9917110325", "7500725707", new BigDecimal("5.6"));
	    //walS.showBalance( "7500725707");
	   
	}
	}

