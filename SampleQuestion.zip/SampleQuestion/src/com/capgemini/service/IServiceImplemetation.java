package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.IDaoLayer;

public class IServiceImplemetation implements IService {
    IDaoLayer idao;
	public IServiceImplemetation(IDaoLayer idao) {
		super();
		this.idao = idao;
	}

	@Override
	public void addFeedback(Trainer trainer) {
		idao.addFeedback(trainer);
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) {
		HashMap<Integer, Trainer> map=	idao.getTrainerList(rating);
		return map;
	}

}
