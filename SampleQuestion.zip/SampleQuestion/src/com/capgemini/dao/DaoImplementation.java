package com.capgemini.dao;
import java.util.HashMap;

import java.util.Map.Entry;

import com.capgemini.beans.Trainer;
import com.capgemini.util.UtilClass;

public class DaoImplementation implements IDaoLayer{
	//HashMap<Integer, Trainer> feedbackList=new UtilClass().getFeedbackList();
	HashMap<Integer, Trainer> feedbackList=UtilClass.getFeedbackList();
	@Override
	public void addFeedback(Trainer trainer) {	
		int id=(int) (Math.random()*(1000));
		feedbackList.put(id, trainer);
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) {
		HashMap<Integer, Trainer> map1=new HashMap<>();
		for(Entry<Integer,Trainer> entry:feedbackList.entrySet())
			if(entry.getValue().getRating()==rating)
				map1.put(entry.getKey(),entry.getValue());
		
		return map1;
	}

}
