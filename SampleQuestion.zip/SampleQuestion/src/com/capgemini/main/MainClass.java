package com.capgemini.main;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.DaoImplementation;
import com.capgemini.dao.IDaoLayer;
import com.capgemini.service.IService;
import com.capgemini.service.IServiceImplemetation;

public class MainClass {
        public static void main(String[] args) {
			IDaoLayer idao=new DaoImplementation();
			IService iser=new IServiceImplemetation(idao);
			Scanner sc=new Scanner(System.in);
			
			int feedback=sc.nextInt();
			sc.nextLine();
			String courseName=sc.nextLine();
			String name=sc.nextLine();
			
			int year1=sc.nextInt();
			int month1=sc.nextInt();
			int date1=sc.nextInt();
			
			int year2=sc.nextInt();
			int month2=sc.nextInt();
			int date2=sc.nextInt();
			
			
			LocalDate startDate =LocalDate.of(year1, month1, date1);
			LocalDate endDate =LocalDate.of(year2, month2, date2);
			
			Trainer trainer=new Trainer();
			trainer.setCourseName(courseName);
			trainer.setName(name);
			trainer.setStartDate(startDate);			
			trainer.setEndDate(endDate);
			trainer.setRating(feedback);
			
			
			iser.addFeedback(trainer);
			HashMap<Integer,Trainer> map=iser.getTrainerList(feedback);
			System.out.println(map);
			}

		
		}

