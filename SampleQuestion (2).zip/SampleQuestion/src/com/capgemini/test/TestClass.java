package com.capgemini.test;
import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.DaoImplementation;
import com.capgemini.dao.IDaoLayer;
import com.capgemini.exception.FieldCannotBeNull;
import com.capgemini.service.IService;
import com.capgemini.service.IServiceImplemetation;

public class TestClass {
    IService iser;	
	@Before
	public void setUp() throws Exception {
		IDaoLayer idao=new DaoImplementation();
		iser=new IServiceImplemetation(idao);
	}

	@Test(expected=FieldCannotBeNull.class)
	public void test1() throws FieldCannotBeNull
	{
		Trainer tr=new Trainer();
		tr.setCourseName("Java");
		tr.setName(null);
		tr.setRating(3);
		tr.setStartDate(LocalDate.of(2000, 12, 06));
		tr.setEndDate(LocalDate.of(2014, 05, 14));
		iser.addFeedback(tr);
	
	}
  @Test
  public void test2() throws FieldCannotBeNull 
  {

		Trainer tr=new Trainer();
		tr.setCourseName("Java");
		tr.setName("Shivi");
		tr.setRating(3);
		tr.setStartDate(LocalDate.of(2000, 12, 06));
		tr.setEndDate(LocalDate.of(2014, 05, 14));
		iser.addFeedback(tr);
  }
  @Test
    public void test3()
    {
	  HashMap<Integer, Trainer> map1=new HashMap<>();
		map1 = iser.getTrainerList(4);
	assertEquals(1, map1.size());
    }
}
