package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.exception.FieldCannotBeNull;

public interface IService {
	public void addFeedback(Trainer trainer) throws  FieldCannotBeNull;
	public HashMap<Integer,Trainer> getTrainerList(int rating);
	public boolean validRating(int rating);
	
	public boolean validCourseName(String courseName);
	
}
