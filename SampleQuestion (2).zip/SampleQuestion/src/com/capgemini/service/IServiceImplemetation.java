package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.IDaoLayer;
import com.capgemini.exception.FieldCannotBeNull;

public class IServiceImplemetation implements IService {
    IDaoLayer idao;
	public IServiceImplemetation(IDaoLayer idao) {
		super();
		this.idao = idao;
	}

	@Override
	public void addFeedback(Trainer trainer) throws FieldCannotBeNull {
		if(trainer.getCourseName()==null || trainer.getName()==null || trainer.getRating()<0
				|| trainer.getCourseName().equals("")||trainer.getName().equals(""))
			throw new FieldCannotBeNull();
		idao.addFeedback(trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) {
		HashMap<Integer, Trainer> map=	idao.getTrainerList(rating);
		return map;
	}

	@Override
	public boolean validRating(int rating) {
		if(rating>1 && rating<6)
			return true;
		return false;
	}


	@Override
	public boolean validCourseName(String courseName) {
		if(courseName.equals("Java")||courseName.equals("Spring")||courseName.equals("JPA"))
			return true;
		return false;
	}

}
