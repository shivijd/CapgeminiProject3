package com.capgemini.exception;

public class FieldCannotBeNull extends Exception {
	public FieldCannotBeNull()
	{
		System.out.println("Not Null");
	}
}
