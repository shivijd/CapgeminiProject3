package com.capgemini.util;

import java.time.LocalDate;
import java.util.HashMap;

import com.capgemini.beans.Trainer;

public class UtilClass {
	static private HashMap<Integer, Trainer> feedbackList = new HashMap<>();

	static {
		feedbackList.put(41, new Trainer("Smitha", "Java", LocalDate.of(2000, 03, 13), LocalDate.of(2000, 04, 10), 5));
		feedbackList.put(22, new Trainer("Smitha", "Java", LocalDate.of(2000, 03, 13), LocalDate.of(2000, 04, 10), 4));
		feedbackList.put(43, new Trainer("Smitha", "Java", LocalDate.of(2000, 03, 13), LocalDate.of(2000, 04, 10), 3));

	}

	public static HashMap<Integer, Trainer> getFeedbackList() {
		return feedbackList;
	}

}
