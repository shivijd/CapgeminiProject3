package com.capgemini.main;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.beans.Trainer;
import com.capgemini.dao.DaoImplementation;
import com.capgemini.dao.IDaoLayer;
import com.capgemini.exception.FieldCannotBeNull;
import com.capgemini.service.IService;
import com.capgemini.service.IServiceImplemetation;

public class MainClass {
	private static Scanner sc = new Scanner(System.in);
	private static IDaoLayer idao = new DaoImplementation();
	private static IService iser = new IServiceImplemetation(idao);

	public static void main(String[] args) throws FieldCannotBeNull {

		// **********************************************************************//
		int choice = sc.nextInt();
		while (true) {
			switch (choice) {
			case 1:
				addDetails();
				break;
			case 2:
				System.exit(0);
				break;
			}

		}

	}

	private static void addDetails() throws FieldCannotBeNull {
		System.out.println("Enter feedback");
		int feedback = sc.nextInt(); // Enter rating
		sc.nextLine();

		while (!(iser.validRating(feedback))) {
			System.out.println("Please enter correct feedback ");
			feedback = sc.nextInt();
		}

		System.out.println("Enter courseName");
		String courseName = sc.nextLine();
		while (!(iser.validCourseName(courseName))) {
			System.out.println("Please Enter Correct CourseName");
		}

		System.out.println("Enter the name of trainer");
		String name = sc.nextLine().trim();

		LocalDate startDate;
		LocalDate endDate;

		// ************************************************************************//
		while (true) {
			try {
				System.out.println("Enter the startyear");
				int year1 = sc.nextInt();

				System.out.println("Enter the start month");
				int month1 = sc.nextInt();

				System.out.println("Enter the start date");
				int date1 = sc.nextInt();

				startDate = LocalDate.of(year1, month1, date1);
				break;
			} catch (Exception e) {
				System.out.println("start date is invalid");
			}
		}

		while (true) {
			try {
				System.out.println("Enter the endyear");
				int year2 = sc.nextInt();

				System.out.println("Enter the end month");
				int month2 = sc.nextInt();

				System.out.println("Enter the end date");
				int date2 = sc.nextInt();

				endDate = LocalDate.of(year2, month2, date2);
				break;
			} catch (Exception e) {
				System.out.println("End date is invalid");
			}
		}

		Trainer trainer = new Trainer(); // Creating Trainer object
		trainer.setCourseName(courseName); // Set CourseName
		trainer.setName(name); // Set name
		trainer.setStartDate(startDate); // Set startName
		trainer.setEndDate(endDate); // Set endDate
		trainer.setRating(feedback); // Set feedback

		iser.addFeedback(trainer); // Adding Trainer Object

		HashMap<Integer, Trainer> map = iser.getTrainerList(feedback); // Getting Trainer List and store it in to
																		// HashMap
		System.out.println(map); // Print HashMap
	}

}
